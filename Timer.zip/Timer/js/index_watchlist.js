$(document).ready(function(){
	var title = $('#title').val();

	    $("nav li a[id='" + title + "']").css({
        "color": "#48ffff",
        "border-bottom": "1px solid #95ffff"
    });

});