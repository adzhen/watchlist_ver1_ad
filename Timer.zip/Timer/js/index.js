$(window).load(function () {
    if (($(window).height()) > 800) {
        $(".login").css("zoom", "135%");
        $(".carousel-inner").css("font-size", "3vmin");
        $(".header_version , .header_tour").css("font-size", "3vmin");
        $(".carousel-indicators").css("bottom", "5px")
    }

});

$(document).ready(function() {
    $("#btn_login").on('click', function(data, success) {
        Presession()
    })
});

function LoginPost(username, password, randomkey) {
    var jsonData = {
        "Username": username,
        "Password": password,
        "RandomKey": randomkey,
    };
    $.ajax({
        datatype: "JSON",
        url: '/MobileControlService.svc/Login',
        type: 'POST',
        contentType: 'application/json;',
        data: JSON.stringify(jsonData),
        success: function(data, success) {
            switch (data.LoginResult.LoginStatusCode) {
                case 0:
                    localStorage.setItem("CQMobileToken", data.LoginResult.Token)
                    window.location.replace("/Mobile/index_watchlist.html");
                    break;
                case 1:
                    alert("Invalid Username/Password.");
                    break;
                case 2:
                    alert("Username/Password should not be blank.");
                    break;
                case 3:
                    alert("Exceeded Login Attempt.");
                    break;
                case 4:
                    alert("Account Inactive.");
                    break;
                case 5:
                    localStorage.setItem("CQMobileToken", data.LoginResult.Token)
                    alert("Warning, default password is insecure.");
                    window.location.replace("/Mobile/index_watchlist.html");
                    break;
                case 6:
                    localStorage.setItem("CQMobileToken", data.LoginResult.Token)
                    alert("Reminder, password expiring soon.");
                    window.location.replace("/Mobile/index_watchlist.html");
                    break;
            }
        },
        error: function(){
            alert("Login failed.");
        }
    })

}


function validate(username, password) {
    if (username.trim() == "") {
        alert("Username cannot be blank.");
        return false;
    } else if (password == "") {
        alert("Password cannot be blank.");
        return false
    } else {
        return true;
    }
}

function Presession() {
    $.ajax({
        datatype: "JSON",
        url: '/MobileControlService.svc/GeneratePresession',
        type: 'POST',
        contentType: 'application/json;',
        success: function(data) {
            async: false,
            $('#hdnE2EEPublicKey').val(data.GeneratePresessionResult.PublicKey);
            $('#hdnE2EESessionId').val(data.GeneratePresessionResult.SessionID);
            $('#hdnE2EERandomNum').val(data.GeneratePresessionResult.RandomNumber);

            if ($('#hdnE2EEPublicKey').length > 0) {
                var publickey = $('#hdnE2EEPublicKey').val()
                var sid = $('#hdnE2EESessionId').val()
                var clientRandom = $('#hdnE2EERandomNum').val()
                var rsa = new RSAEngine();
                rsa.init(publickey, sid, clientRandom)


                var username = $('#input-user1').val();
                var password = fnGetRPIN($('#input-pwd1')[0], rsa);

                if (validate(username, password)) {
                    GetClientIP();
                    LoginPost(username, password, clientRandom);
                }
            }
        }
    })
}

function GetClientIP() {
    $.ajax({
        datatype: "JSON",
        url: '/MobileControlService.svc/GetClientIP',
        type: 'POST',
        contentType: 'application/json;',
        success: function(data) {
            localStorage.setItem("loginIP", data.GetClientIPResult);
        }
    })
}