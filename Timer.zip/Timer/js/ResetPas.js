$(document).ready(function() {
    $('#input-user1').val("ThisUser");

    $('#pwd-info').on('click', function() {
        alert("1.Must more than 8 characters.\n2.Contain three of the following categories\n * Atleast one upper case characters.\n * Atleast one lower case characters.\n * Atleast one numeric number.\n * Atleast one Non-alphanumeric characters.\n");
    })

    $('#btn_back').on('click', function() {
        var color = getRandomColor();
        $("#intro").css('color', color);
        $("h1").css('color', color);
    })

    $('#input-new-pwd1').on('change', function() {
        var ele = document.getElementById("input-re-pwd1");
        validator_ConfirmPwd(ele);
    })

});

function validator_ConfirmPwd(inputbox) {
    var input = $('#input-re-pwd1').val();
    var newPwd = $('#input-new-pwd1').val();


    if (input != newPwd) {
        $('#input-re-pwd1').css("border", "2px solid rgba(255, 0, 0, 0.4)");
        inputbox.setCustomValidity(" * Passwords Don't Match");
    } else {
        $('#input-re-pwd1').css("border", "2px solid rgba(0, 255, 0, 0.4)");
        inputbox.setCustomValidity("");
    }
}

function validator(inputbox) {
    var error = "Please match the requested format.\n";
    var count = 4;
    var lowercase = /(?=.*[a-z])/;
    var uppercase = /(?=.*[A-Z])/;
    var numeric = /[0-9]/
    var special = /[^a-zA-Z0-9]/;
    var input = $('#input-new-pwd1').val();
    var max = /.{8,}/;

    if (input.match(max)) {
        if (!input.match(uppercase)) {
            count--;
            error = error + " * Atleast one upper case characters.\n";
        }
        if (!input.match(lowercase)) {
            count--;
            error = error + " * Atleast one lower case characters.\n";
        }
        if (!input.match(numeric)) {
            count--;
            error = error + " * Atleast one numeric number.\n";
        }
        if (!input.match(special)) {
            count--;
            error = error + " * Atleast one Non-alphanumeric characters.\n";
        }

        if (count < 3) {
            $('#input-new-pwd1').css("border", "2px solid rgba(255, 0, 0, 0.4)");
            inputbox.setCustomValidity(error);
        } else {
            $('#input-new-pwd1').css("border", "2px solid rgba(0, 255, 0, 0.4)");
            inputbox.setCustomValidity('');
        }
    } else {
        error = error + " * At least 8 or more characters."
        $('#input-new-pwd1').css("border", "2px solid rgba(255, 0, 0, 0.4)");
        inputbox.setCustomValidity(error);
    }

}

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
