function CheckTokenValidity(callback) {
    var jsonData = {
        "Token": localStorage.getItem("CQMobileToken")
    };

    $.ajax({
        datatype: "JSON",
        url: '/MobileControlService.svc/IsValidToken',
        contentType: 'application/json;',
        type: 'POST',
        data: JSON.stringify(jsonData),
        success: function(data, success) {
            //alert("Token is " + data.IsValidTokenResult);
            if (data.IsValidTokenResult == false) {
                alert("New session detected. Current session will be logged out.")
                Logout();
            } else {
                if (typeof callback === "function") {
                    callback(data.IsValidTokenResult);
                }
            }
        },
        error: function() {
            //callback(false);
        }
    })
}

function ConnectionDropEvent() {
    window.addEventListener("offline", function(e) {
        alert("Internet connection has been lost. \nCurrent session will logout.");
        Logout();
    }, false);
}

function Logout() {
    localStorage.removeItem("loginIP");
    localStorage.removeItem("CQMobileToken");
    window.location.replace("./index.html");
}

$(document).ready(function() {
    // setTimeout(function timer() {
    //     alert("Times out, call function()");
    //     Logout();
    // }, 10000);
})

var idleTime = 0;
$(document).ready(function() {
    //Increment the idle time counter every minute.
    var idleInterval = setInterval(timerIncrement, 1000); // 1 sec

    //Zero the idle timer on mouse movement.
    $(this).mousemove(function(e) {
        console.log("Mouse click");
        idleTime = 0;
    });
    $(this).keyup(function(e) {
        console.log("typing");
        idleTime = 0;
    });

});

function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime > 9) { // 10 sec
        confirm("Times out (10 seconds), force logout");
        Logout();
    }
}
